import json
from models.movie import Movie
from models.user import User
from models.rental_system import RentalSystem

rental= RentalSystem()

print("Welcome to Movie Rental System!\n")

print("Write the number of the option you want to choose.\n")

while True:
    try:
        options= int(input("1. Add a movie \n2. View available movies\n3. View rented movies\n4. Rent a movie\n5. Return a movie\n6. Add a user\n 7. Remove a user\n8.Exit"))
    except ValueError:
        print("Invalid input.")
        continue
    if options not in [1,2,3,4,5,6,7,8]:
        print("Invalid option. You can only choose numbers from 1 to 8.")
        continue

    if options==1:
        title= input("Enter movie title: ")
        genre= input("Enter movie genre: ")
        movie= Movie(title, genre)
        rental.add_movie(movie)
    elif options==2:
        rental.view_available_movies()
    elif options==3:
        rental.view_rented_movies()
    elif options==4:
        rental.rent_movie()
    elif options==5:
        rental.return_movie()
    elif options==6:
        name= input("Enter user name: ")
        import random
        id= random.randint(100,999)
        new_user= User(name, id)
        rental.add_user(new_user)
    elif options==7:
        rental.remove_user()
    elif options==8:
        rental.save_movies()
        rental.save_users()
        print("Thanks for using the Rental Movie System!")
        break
    
