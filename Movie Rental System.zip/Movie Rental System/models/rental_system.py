import json
from movie import Movie
from user import User
from clean import Clean



class RentalSystem:

    def __init__(self, movies= None, users= None):
        self.movies= movies if movies is not None else []
        self.users= users if users is not None else []

    def load_movies(self):
            try:
                with open ("movies.json", "r") as f:
                    self.movies= json.load(f)
            except (FileNotFoundError, json.JSONDecodeError) as e:
                print(f"{e}: No file with this name found, staring anew!") 
                self.movies=[]

    def save_movies(self):
        try:
            with open("movies.json", "w") as f:
                json.dump(self.movies, f, indent= 4)
        except IOError:
            print("There was a problem when handling this file.")

    def add_movie(self, movie):
        self.load_movies()
        if isinstance (movie, Movie):
            formatted_title=Clean.format_title(movie.title)
            self.movies.append({
                'title': formatted_title,
                'genre': movie.genre,
                'is_available': movie.is_available
            })
        self.save_movies()
        print(f"{formatted_title} has been added to the library of existing movies.")


    def rent_movie(self):
        to_rent=input("What's the title of teh movie you want to rent? ")
        self.load_movies()
        found= False
        for movie in self.movies:
            if movie['title']==to_rent:
                if movie['is_available']:
                    movie['is_available']= False
                    found= True
                    print(f"You've just rented {movie['title']}. Enjoy!")
        if not found:
            print(f"Sorry, {to_rent} is either unavailabl or already rented.")
        self.save_movies()

    def return_movie(self):
        to_return=input("What's the title of teh movie you want to return? ")
        self.load_movies()
        found= False
        for movie in self.movies:
            if movie['title']==to_return:
                if not movie['is_available']:
                    movie['is_available']= True
                    found= True
                    print(f"You've just returned {movie['title']}.")
        if not found:
            print(f"Sorry, {to_return} is either not rented or does not exist.")
        self.save_movies()

    def view_available_movies(self):
        self.load_movies()
        found= False
        print("Available movies: \n")
        for movie in self.movies:
            if movie['is_available']==True:
                print(f"-{movie['title']}, {movie['genre']}")
                found= True
        if not found:
            print("No movies are currently available.")

    def view_rented_movies(self):
        self.load_movies()
        found=False
        print("REnted movies: \n")
        for movie in self.movies:
            if movie['is_available'] == False:
                print(f"-{movie['title']}, {movie['genre']}")
                found= True
        if not found:
            print("No movies are currently rented.")

    def load_users(self):
        try:
            with open("users.json", "r") as f:
                self.users= json.load(f)
        except (FileNotFoundError,  json.JSONDecodeError) as e:
            print(f"{e}: There's no users file, starting anew!")
            self.users=[]

    def save_users(self):
        try:
            with open("users.json", "w") as f:
                json.dump(self.users, f, indent= 4)
        except IOError:
            print("There was a problem making changes to this file.")

    def add_user(self, user):
        self.load_users()
        if isinstance(user, User):
            self.users.append({
                'name': user.name,
                'id': user.id,
                'rented_movies': user.rented_movies
            })
        self.save_users()
        print(f"{user.name} is now a member of the movie rental services.")

    def remove_user(self):
        self.load_users()
        updated_users=[]
        remove_user=int(input("Type the id of the usr you want to remove: "))
        found=False
        for user in self.users:
            if remove_user != user['id']:
                updated_users.append(user)
            else:
                found= True
                
        self.users= updated_users
        if found:
            print(f"The user with ID {remove_user} has been removed.")
        else:
            print("No user with the ID you entered is registered.")     
        self.save_users()
        
                
