


class User:

    def __init__(self, name, id, rented_movies=None):
        self.name= name
        self.id= id
        self.rented_movies= rented_movies if rented_movies is not None else []
