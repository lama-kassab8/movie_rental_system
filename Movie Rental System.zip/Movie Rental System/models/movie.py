

class Movie:

    def __init__(self, title, genre, is_available):
        self.title= title
        self.genre= genre
        self.is_available= is_available

        