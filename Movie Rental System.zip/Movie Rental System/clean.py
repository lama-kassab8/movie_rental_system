class Clean:
    # I created this seperate class to clean up user's input, following the English Grammar as the words in the lower_case list should be lower case when they're not in the beginning of the title.

    @staticmethod #So that i can call it without needing an instance of the class Clean.
    def format_title(title):
        lower_case = ["a", "an", "the", "and", "or", "for", "by", "to", "of", "at", "but"]
        words = title.split()  # This line breaks the title into words.
        for i in range(len(words)):  # This iterates through each word by index.
            if words[i].lower() not in lower_case:  # This line checks if the word is not of of the lower case words.
                words[i] = words[i].title()  # Now the word is capitalized and the list is updated.
        return ' '.join(words)  #Fianlly, I join the words back into a single string.